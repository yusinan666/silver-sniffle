<p align="center">
  <a href="https://github.com/Gustiagung19/gusti-status-server-web" target="_blank">
    <img src="https://imgur.com/w2CjR0C.png" alt="Logo" width="690" height="388">
  </a>
</p>
<h3 align="center">[FREE] Gusti Status Server Web</h3>
<p align="center">
  gusti-status-server-web is where players can see the fivem server status through the website and make it easier for them to join the server, and see the number of players on the server.
  <br />
  <br />
  <a href="https://youtu.be/B3hScIpCZaM">View Demo</a>
  ·
  <a href="https://github.com/Gustiagung19/gusti-status-server-web/issues">Report Bug</a>
  ·
  <a href="https://github.com/Gustiagung19/gusti-status-server-web/issues">Request Feature</a>
</p>


## Documentation
- [AKL DOCUMENTATION](https://aklgaming.gitbook.io/documentation/gusti-resources/gusti-status-server-web)

## Credit Template
- [Bootstrap](https://getbootstrap.com/)

[![Contributors][contributors-shield]][contributors-url]
[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![Issues][issues-shield]][issues-url]

[contributors-shield]: https://img.shields.io/github/contributors/Gustiagung19/gusti-status-server-web.svg?style=for-the-badge
[contributors-url]: https://github.com/Gustiagung19/gusti-status-server-web/graphs/contributors
[forks-shield]: https://img.shields.io/github/forks/Gustiagung19/gusti-status-server-web.svg?style=for-the-badge
[forks-url]: https://github.com/Gustiagung19/gusti-status-server-web/network/members
[stars-shield]: https://img.shields.io/github/stars/Gustiagung19/gusti-status-server-web.svg?style=for-the-badge
[stars-url]: https://github.com/Gustiagung19/gusti-status-server-web/stargazers
[issues-shield]: https://img.shields.io/github/issues/Gustiagung19/gusti-status-server-web.svg?style=for-the-badge
[issues-url]: https://github.com/Gustiagung19/gusti-status-server-web/issues
